GAMEVAULT 4.8

GameVault là nhật ký tài khoản dạng thẻ, lưu dữ liệu mã hóa trên máy Windows.
Phiên bản 4.8 giữ tương thích với kho GameVault 3.0/4.x hiện có.

TRẢI NGHIỆM CHÍNH
- Trung tâm Cần xử lý phân nhóm thiếu Gmail, thiếu mật khẩu, chưa xác nhận và tài khoản lâu chưa kiểm tra.
- Mỗi tài khoản có lịch sử tạo mới, chỉnh sửa, ghi chú, trạng thái và đồng bộ.
- Lịch sử đồng bộ RAM lưu số lượng thêm mới, cập nhật và bỏ qua của từng phiên.
- Giao diện thẻ nhẹ, có ngăn chi tiết và thanh thao tác tối giản.
- Thẻ ID nhỏ gọn hơn và luôn hiển thị đầy đủ ID, Gmail, trạng thái.
- Danh sách dùng thẻ vẽ nhẹ để chuyển mục nhanh và mượt hơn.
- Các mục Tất cả, Cần xử lý, Đã xác nhận, Roblox RAM và Nhập thủ công.
- Quản lý theo Gmail: tổng số Gmail, số tài khoản và danh sách ID trong từng Gmail.
- Có thể thêm tài khoản trực tiếp vào Gmail đang chọn.
- Nút + Thêm hỗ trợ cả một tài khoản và nhiều tài khoản trong cùng một luồng.
- Nhập hàng loạt bằng cách dán danh sách hoặc mở TXT/CSV; có xem trước, báo trùng ID và dòng lỗi trước khi lưu.
- Có thể tích dùng một Gmail chung rồi nhập nhanh 5-50 tài khoản; Gmail chỉ cần nhập một lần.
- Có thể tích dùng một mật khẩu chung; mật khẩu được áp dụng cho ID mới và cập nhật hàng loạt ID đã có.
- ID mới được tạo, ID đã có được đồng bộ mật khẩu/Gmail và tự chuyển về đúng nhóm Gmail.
- Trong Quản lý theo Gmail có thể chọn nhiều tài khoản đang có để gắn chung một Gmail.
- Khi dán danh sách từ website Roblox, ERP tự lấy dòng @username, bỏ dấu @ và bỏ qua tên hiển thị.
- Bảng chi tiết hiển thị tổng quan toàn kho khi chưa chọn tài khoản.
- Hiện/ẩn mật khẩu và chỉnh ghi chú trực tiếp trong ngăn chi tiết.
- CSV chỉ gồm ID, Mật khẩu và Gmail; mở Excel sẽ tự vào đúng ba cột.
- Nhận diện Wang Huy đặt ở đầu sidebar và icon ứng dụng được khôi phục.
- Tìm nhanh theo ID, Gmail, trò chơi hoặc ghi chú.
- Phím tắt: Ctrl+F để tìm, Ctrl+N để thêm thẻ.
- Chống tạo ID trùng, hiển thị rõ nguồn và thời gian cập nhật.

ĐỒNG BỘ ROBLOX ACCOUNT MANAGER
- Đồng bộ hai chiều rõ ràng: RAM → ERP và ERP → RAM.
- ERP → RAM chỉ gửi tài khoản đã xác nhận ID/mật khẩu đúng.
- Mật khẩu và Gmail đã đổi được cập nhật đầy đủ theo cả hai chiều ERP ↔ RAM.
- Đọc được cả ngày ISO-8601 và định dạng ngày cũ trong AccountData của RAM.
- Khi RAM không có Gmail, đồng bộ RAM → ERP luôn giữ Gmail đang có trong ERP.
- Bảng xem trước hiển thị Gmail cuối cùng, nguồn giữ từ ERP và số tài khoản đang chọn.
- Thanh thao tác đồng bộ co giãn đúng cửa sổ; nút đồng bộ luôn hiển thị.
- Phân biệt tài khoản RAM có phiên Join hợp lệ và mục mới chưa đăng nhập.
- Không còn tạo mục RAM chỉ có ID/MK nhưng thiếu SecurityToken/UserID.
- Luồng Chuẩn bị đăng nhập bằng RAM sao lưu, dọn mục vỏ cũ và tạo danh sách user:pass
  tạm thời để RAM đăng nhập native, xử lý CAPTCHA/2FA và nhận phiên thật.
- Tài khoản có phiên RAM hợp lệ được đánh dấu MK chính xác; nếu thiếu Gmail chỉ còn
  trạng thái Chờ cập nhật Gmail.
- Trong từng nhóm Gmail, tài khoản đã xác nhận và tài khoản có MK chính xác được xếp lên đầu.
- Tích Xác nhận acc OK nằm ngay dưới mật khẩu trong bảng chi tiết, không cần mở menu ba chấm.
- Chặn hoàn toàn ghi AccountData khi Roblox Account Manager đang mở để tránh RAM
  ghi đè dữ liệu ngay sau khi ERP ghi và gây rollback.
- Hàng đợi đăng nhập RAM giới hạn tối đa 5 tài khoản mỗi đợt.
- Tài khoản đã có phiên Join và không đổi mật khẩu/Gmail được ẩn khỏi danh sách đồng bộ.
- Tự loại ID trùng trong hàng đợi; tài khoản chỉ xuất hiện lại khi có dữ liệu mới cần cập nhật.
- Không xóa tài khoản RAM, luôn sao lưu AccountData và đọc lại để kiểm tra sau khi ghi.
- Giữ nguyên cookie phiên, UserID, nhóm, mô tả và trường tùy chỉnh đang có trong RAM.
- Bảng xem trước có thống kê, màu phân loại, chọn nhanh thay đổi và bỏ chọn toàn bộ.
- Bấm Đồng bộ và chọn AccountData.json ở lần đầu.

ĐỒNG BỘ MÁY CHỦ / MÁY CON (LAN)
- Máy giữ kho chính chọn Đồng bộ > Đồng bộ máy chủ / máy con > Bật máy này làm máy chủ.
- Đặt mã ghép nối từ 10 ký tự và gửi địa chỉ IP, cổng, mã này cho máy con bằng kênh an toàn.
- Máy con chọn Nhận kho từ máy chủ và nhập đúng ba thông tin trên.
- Máy con có thể chọn Gửi thay đổi lên máy chủ; máy chủ sẽ thấy số mục thêm/sửa và phải duyệt.
- Việc gửi ngược không tự xóa tài khoản chỉ có trên máy chủ.
- Máy con ghi nhớ kết nối và chỉ gửi các tài khoản đã thay đổi từ lần đồng bộ thành công gần nhất.
- Khi có xung đột, YES dùng bản máy con; NO giữ bản máy chủ ở mục xung đột; CANCEL từ chối yêu cầu.
- GameVault mã hóa dữ liệu khi truyền, hỏi xác nhận và sao lưu kho máy con trước khi thay thế.
- Máy chủ phải mở GameVault trong lúc máy con nhận dữ liệu; hai máy cần cùng mạng LAN.
- Nếu kết nối lỗi, hãy cho phép GameVault.exe trong Windows Firewall.

MỞ ỨNG DỤNG
- GameVault mở thẳng, không yêu cầu đăng nhập hằng ngày và không tự khóa.
- Kho vẫn được mã hóa bằng khóa do tài khoản Windows hiện tại bảo vệ.
- Khi nâng cấp từ bản cũ, ứng dụng chỉ có thể hỏi mật khẩu một lần để chuyển kho sang chế độ mở tự động.
- Bản 4.12 mở mặc định tại Quản lý theo Gmail và có tab Kết nối chủ - con riêng trên sidebar.
- Thao tác xác nhận/trạng thái lưu nền để giảm khựng; bỏ tích xác nhận sẽ bỏ cả dấu xác minh liên quan.
- Bản 4.13 tách lựa chọn ERP → RAM thành Gửi ngay và Đăng nhập. ID chưa có phiên phải được chọn ở cột Đăng nhập, chuẩn bị tối đa 5 ID, đăng nhập trong RAM rồi mới gửi cập nhật.
- Bản 4.14 làm mới thẻ Gmail với bo góc, bóng, huy hiệu số lượng, thống kê xác nhận/cần xử lý và hiệu ứng rê chuột.
- Bản 4.15 tối ưu cửa sổ mặc định: tên Gmail rộng và xanh đậm, bỏ chữ G, sidebar navy–indigo và bảng tổng quan phải gọn thành một khối.
- Bản 4.16 đưa Đồng bộ ra sidebar, gom RAM hai chiều và LAN vào trung tâm kiểm soát, đổi sidebar sapphire–graphite và làm mới thẻ Gmail.
- Bản 4.17 tinh gọn sidebar còn Gmail, Cần xử lý và Đồng bộ; tìm kiếm toàn kho có bộ lọc; LAN gộp vào Đồng bộ; khôi phục hỗ trợ hợp nhất.
- Bản 4.18 tách Kết nối LAN trở lại sidebar, giữ Đồng bộ riêng cho Roblox RAM và thêm bảng công năng khi rê chuột lên từng mục.
- Bản 4.19 ưu tiên kết quả theo độ khớp ID và thêm nút sao chép nhanh ID/MK ngay trên thẻ tài khoản.
- Bản 4.20 hiện mật khẩu che cạnh ID, có công tắc hiện toàn bộ kết quả và làm mềm nút sao chép dạng pill.
- Bản 4.21 tự xóa tìm kiếm khi chuyển tab và đưa công tắc MK nhỏ lên cạnh tiêu đề kết quả.
- Bản 4.22 đổi công tắc MK thành checkbox, kéo MK sát ID và tăng cỡ/độ đậm các tab sidebar.
- Bản 4.23 bổ sung cập nhật trực tuyến: kiểm tra phiên bản, tải có SHA-256, UpdateService backup/rollback và gói update tự sinh khi build.
- Bản 4.24 hiện đại hóa toàn bộ giao diện theo phong cách Fluent/Windows 11: đồng bộ màu sắc, font, sidebar, tìm kiếm, card Gmail, thống kê, bảng dữ liệu và thanh trạng thái; không thay đổi nghiệp vụ.
- GameVault ghi nhớ đường dẫn cho những lần sau.
- Luôn xem trước Thêm mới, Cập nhật, Bổ sung Email và Không đổi.
- Tự tạo bản an toàn trước khi áp dụng thay đổi.
- Không nhập cookie Roblox vào GameVault.

AN TOÀN DỮ LIỆU
- Kho chính được mã hóa và gắn với máy hiện tại.
- Bản sao .gvp có mật khẩu riêng và có thể chuyển máy.
- Clipboard chứa mật khẩu được tự xóa sau 20 giây.
- Kho tự khóa sau 5 phút không hoạt động.
- Khôi phục, đổi mật khẩu và cập nhật hàng loạt đều tạo bản an toàn.

MENU BA CHẤM
- Nhập TXT, cập nhật Gmail, xuất CSV.
- Sao lưu, khôi phục, đổi mật khẩu và khóa kho.

YÊU CẦU
- Windows và .NET Framework 4.6.1 trở lên.

TỰ BUILD
- Nhấp đúp Build-Setup.bat.
- Cần Inno Setup 6 để tạo bộ cài GameVault ERP theo phiên bản hiện tại.
